<?php

?>
<!-- Start footer js Import -->

    <script src="<?php echo base_url();?>assets/javascripts/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery-ui.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/raphael.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/selectivizr-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.mousewheel.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.vmap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.vmap.sampledata.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.vmap.world.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.bootstrap.wizard.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/fullcalendar.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/gcal.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/datatable-editable.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.easy-pie-chart.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/excanvas.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.isotope.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/isotope_extras.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/modernizr.custom.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.fancybox.pack.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/select2.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/styleswitcher.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/wysiwyg.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/typeahead.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/summernote.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.inputmask.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.validate.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/bootstrap-fileupload.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/bootstrap-datepicker.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/bootstrap-timepicker.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/bootstrap-colorpicker.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/typeahead.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/spin.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/ladda.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/moment.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/mockjax.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/bootstrap-editable.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/xeditable-demo-mock.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/xeditable-demo.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/address.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/daterange-picker.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/date.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/morris.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/skycons.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/fitvids.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.sparkline.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/dropzone.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/jquery.nestable.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/main.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/javascripts/respond.js" type="text/javascript"></script>
    
    <!-- Pricing Table -->

    <script src="<?php echo base_url();?>assets/pricing/js/tooltipster/tooltipster.bundle.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/pricing/js/solid-pricing.js" type="text/javascript"></script>

    <!-- End Pricing Table -->
    <!-- post data with validation script -->

    <script src="<?php echo base_url();?>assets/javascripts/post_get_data.js" type="text/javascript"></script>

    <!-- start validation message with variables -->
    <script src="<?php echo base_url();?>assets/javascripts/validation_message.js" type="text/javascript"></script>

    

   <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script> -->
    <script type="text/javascript" src="<?php echo base_url()?>assets/javascripts/video.js"></script>

    <!-- End Header Css Import -->
    <script type="text/javascript">
        var base_url = '<?php echo base_url(); ?>';
    </script>

    <script type="text/javascript"> 
     $(document).ready(function(){

        $('.span_id').on('click', function(){
          text = $(this).closest('td').find('span#ading_id').text();
          var campaign_name = $(this).closest('td').find('span#campaign_title').text();
          var ad_title = $(this).closest('td').find('span#ads_title').text();
          $('#txt_ad_name').text(ad_title);
          $('#txt_campaign_name').text(campaign_name);
        });
      });
     </script>

    <script type="text/javascript">
    $(document).ready(function () {
      var url = window.location;
// Will only work if string in href matches with location
        $('ul.nav a[href="'+ url +'"]').parent().addClass('current');
    // Will also work for relative and absolute hrefs
    // $('ul.nav a').filter(function() {
    //     return this.href == url;
    // }).parent().addClass('current'); 
    });


    </script>
     
    <!-- <script>
      $(window).load(function(){
        swal("Good job!", "You clicked the button!", "success");
      });
  </script> -->

    <!-- end validation message with variables -->

    <!-- End Post data with validation script -->

    <!-- End Footer Js Import -->
