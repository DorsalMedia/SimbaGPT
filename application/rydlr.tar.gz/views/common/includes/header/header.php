<?php 
?>
<!DOCTYPE html>
<html lang="en">

<?php echo get_head(); ?>

<body class="page-header-fixed bg-1">

    <div class="modal-shiftfix">
      <!-- Navigation -->
      <div class="navbar navbar-fixed-top scroll-hide">
			
			<?php echo get_top_bar(); ?>

			<?php echo get_menu_bar(); ?>
			
			