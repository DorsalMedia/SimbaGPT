<?php 
?>
<!DOCTYPE html>
<html lang="en">

<?php echo get_head(); ?>
	
<body class="page-register-header-fixed bg-3">
    <!-- <div class="modal-shiftfix">
      -->
       <div class="navbars1 navbar-fixed-top scroll-hide"> 
       	<div class="center_me">
			<center>
				<!--<a href="<?php echo base_url(); ?>media_admin/home"><img class="register_resize_logo" src="<?php echo base_url();?>assets/images/logo.png" ></a>-->
				<a href="<?php echo base_url(); ?>media_admin/home" style="display: block;"><img class="register_resize_logo" src="<?php echo base_url();?>assets/images/Rydlr_logo_title.png" ></a>
			</center>
		</div>	
			
			