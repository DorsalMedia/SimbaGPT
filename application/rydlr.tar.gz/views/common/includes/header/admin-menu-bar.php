<?php
	
?>
	<div class="container-fluid main-nav clearfix">
          <div class="nav-collapse">
            <ul class="nav">
              <li>
                <a class="current" href="<?php echo base_url(); ?>media_admin/home"><span aria-hidden="true" class="hightop-home"></span>Dashboard</a>
              </li>
              <li>
                <a href="<?php echo base_url(); ?>media_admin/view_admin_profile"><span aria-hidden="true" class="hightop-feed glyphicon glyphicon-user"></span>Profile</a>
              </li>              
              <li>
              <a href="<?php echo base_url();?>media_admin/view_admin_advertisment"><span aria-hidden="true" class="fa fa-fw fa-bullhorn"></span>Ads</a>           
              </li>
              <li>
              <a href="<?php echo base_url();?>media_admin/view_admin_campaigns"><span aria-hidden="true" class="hightop-charts"></span> Campaigns </a>
              </li>
              <li>
              <a href="<?php echo base_url();?>media_admin/view_admin_contract"><span aria-hidden="true" class="fa fa-fw fa-edit"></span> Contract </a>
              </li>
              <li>
              <a href="<?php echo base_url();?>media_admin/view_admin_payment"><span aria-hidden="true" class="glyphicon glyphicon-usd"></span>Payment</a>
              </li>
              <li>
              <a href="<?php echo base_url();?>media_admin/view_admin_report"><span aria-hidden="true" class="fa fa-file"></span>Reports</a>
              </li>            
            </ul>
          </div>
    </div>