<?php 
?>
<!DOCTYPE html>
<html lang="en">

<?php echo get_head(); ?>
	
<body class="page-register-header-fixed bg-3">
    <!-- <div class="modal-shiftfix">
      -->
       <div class="navbars navbar-fixed-top scroll-hide"> 
       	<div class="center_me">
			<center>
				<a href="<?php echo base_url(); ?>media_admin/home"><img class="register_resize_logo" src="<?php echo base_url();?>assets/images/logo.png" ></a>
			</center>
		</div>	
			
			